/**
 * Badge params
 *
 * logo: its the logo itself
 * logoColor: its the logo color itself
 * labelColor: bg of left side
 * label: text of left side
 * message: text of right side
 * color: bg of right side
 */

const social_icons = [
  {
    name: 'behance',
    icons: ['default'],
    badge: {
      message: 'Behance',
      color: '1769ff',
      label: '',
      logo: 'behance',
      logoColor: 'white',
    },
  },
  {
    name: 'bluesky',
    icons: ['default'],
    badge: {
      message: 'Bluesky',
      color: '0285FF',
      label: '',
      logo: 'bluesky',
      logoColor: 'white',
    },
  },
  {
    name: 'codesandbox',
    icons: ['default'],
    badge: {
      message: 'Codesandbox',
      color: '040404',
      label: '',
      logo: 'codesandbox',
      logoColor: 'DBDBDB',
    },
  },
  {
    name: 'codepen',
    icons: ['default'],
    badge: {
      message: 'Codepen',
      color: '000000',
      label: '',
      logo: 'codepen',
      logoColor: 'white',
    },
  },
  {
    name: 'devto',
    icons: ['default'],
    badge: {
      message: 'dev.to',
      color: '0A0A0A',
      label: '',
      logo: 'dev.to',
      logoColor: 'white',
    },
  },
  {
    name: 'discord',
    icons: ['default'],
    badge: {
      message: 'Discord',
      color: '7289DA',
      label: '',
      logo: 'discord',
      logoColor: 'white',
    },
  },
  {
    name: 'dribbble',
    icons: ['default'],
    badge: {
      message: 'Dribbble',
      color: 'EA4C89',
      label: '',
      logo: 'dribbble',
      logoColor: 'white',
    },
  },
  {
    name: 'facebook',
    icons: ['default'],
    badge: {
      message: 'Facebook',
      color: '1877F2',
      label: '',
      logo: 'facebook',
      logoColor: 'white',
    },
  },
  {
    name: 'gitlab',
    icons: ['default'],
    badge: {
      message: 'GitLab',
      color: 'FC6D26',
      label: '',
      logo: 'gitlab',
      logoColor: 'white',
    },
  },
  {
    name: 'gmail',
    icons: ['default'],
    badge: {
      message: 'Gmail',
      color: 'D14836',
      label: '',
      logo: 'gmail',
      logoColor: 'white',
    },
  },
  {
    name: 'hackerrank',
    icons: ['default'],
    badge: {
      message: 'HackerRank',
      color: '2EC866',
      label: '',
      logo: 'hackerrank',
      logoColor: 'white',
    },
  },
  {
    name: 'instagram',
    icons: ['default'],
    badge: {
      message: 'Instagram',
      color: 'E4405F',
      label: '',
      logo: 'instagram',
      logoColor: 'white',
    },
  },
  {
    name: 'itch',
    icons: ['default'],
    badge: {
      message: 'itch.io',
      color: '000000',
      label: '',
      logo: 'itch',
      logoColor: 'white',
    },
  },
  {
    name: 'linkedin',
    icons: ['default'],
    badge: {
      message: 'LinkedIn',
      color: '0077B5',
      label: '',
      logo: 'linkedin',
      logoColor: 'white',
    },
  },
  {
    name: 'linktree',
    icons: ['default'],
    badge: {
      message: 'Linktree',
      color: '1de9b6',
      label: '',
      logo: 'linktree',
      logoColor: 'white',
    },
  },
  {
    name: 'medium',
    icons: ['default'],
    badge: {
      message: 'Medium',
      color: '12100E',
      label: '',
      logo: 'medium',
      logoColor: 'white',
    },
  },
  {
    name: 'microsoft-outlook',
    short_name: 'outlook',
    icons: ['default'],
    badge: {
      message: 'Outlook',
      color: '0078D4',
      label: '',
      logo: 'microsoft-outlook',
      logoColor: 'white',
    },
  },
  {
    name: 'patreon',
    icons: ['default'],
    badge: {
      message: 'Patreon',
      color: 'F96854',
      label: '',
      logo: 'patreon',
      logoColor: 'white',
    },
  },
  {
    name: 'paypal',
    icons: ['default'],
    badge: {
      message: 'PayPal',
      color: '00457C',
      label: '',
      logo: 'paypal',
      logoColor: 'white',
    },
  },
  {
    name: 'stackoverflow',
    icons: ['default'],
    badge: {
      message: 'Stackoverflow',
      color: 'FE7A16',
      label: '',
      logo: 'stackoverflow',
      logoColor: 'white',
    },
  },
  {
    name: 'telegram',
    icons: ['default'],
    badge: {
      message: 'Telegram',
      color: '2CA5E0',
      label: '',
      logo: 'telegram',
      logoColor: 'white',
    },
  },
  {
    name: 'twitch',
    icons: ['default'],
    badge: {
      message: 'Twitch',
      color: '9146FF',
      label: '',
      logo: 'twitch',
      logoColor: 'white',
    },
  },
  {
    name: 'twitter',
    icons: ['default'],
    badge: {
      message: 'Twitter',
      color: '1DA1F2',
      label: '',
      logo: 'twitter',
      logoColor: 'white',
    },
  },
  {
    name: 'unsplash',
    icons: ['default'],
    badge: {
      message: 'Unsplash',
      color: '111',
      label: '',
      logo: 'unsplash',
      logoColor: 'white',
    },
  },
  {
    name: 'visualstudio',
    icons: ['default'],
    badge: {
      message: 'Visual Studio Marketplace',
      color: 'e2165e',
      label: '',
      logo: 'visualstudio',
      logoColor: 'white',
    },
  },
  {
    name: 'wechat',
    icons: ['default'],
    badge: {
      message: 'WeChat',
      color: '7BB32A',
      label: '',
      logo: 'wechat',
      logoColor: 'white',
    },
  },
  {
    name: 'whatsapp',
    icons: ['default'],
    badge: {
      message: 'Whatsapp',
      color: '25D366',
      label: '',
      logo: 'whatsapp',
      logoColor: 'white',
    },
  },
  {
    name: 'youtube',
    icons: ['default'],
    badge: {
      message: 'Youtube',
      color: 'FF0000',
      label: '',
      logo: 'youtube',
      logoColor: 'white',
    },
  },
  {
    name: 'tutanota',
    icons: ['default'],
    badge: {
      message: 'Tutanota',
      color: '840010',
      label: '',
      logo: 'tutanota',
      logoColor: 'white',
    },
  },
  {
    name: 'matrix',
    icons: ['default'],
    badge: {
      message: 'Matrix',
      color: '000000',
      label: '',
      logo: 'matrix',
      logoColor: 'white',
    },
  },
  {
    name: 'ko-fi',
    icons: ['default'],
    badge: {
      message: 'Ko-fi',
      color: 'F16061',
      label: '',
      logo: 'ko-fi',
      logoColor: 'white',
    },
  },
  {
    name: 'signal',
    icons: ['default'],
    badge: {
      message: 'Signal',
      color: '039BE5',
      label: '',
      logo: 'signal',
      logoColor: 'white',
    },
  },
  {
    name: 'slack',
    icons: ['default'],
    badge: {
      message: 'Slack',
      color: '4A154B',
      label: '',
      logo: 'slack',
      logoColor: 'white',
    },
  },
  {
    name: 'tryhackme',
    icons: ['default'],
    badge: {
      message: 'TryHackMe',
      color: '88cc14',
      label: '',
      logo: 'tryhackme',
      logoColor: 'white',
    },
  },
];

export { social_icons };
